package com.example.sayedmahmoud.egypttourguide;

/**
 * Created by sayed.mahmoud on 6/11/2019.
 */

public class DataModel {

        public String name;
        private int mImageResourceId = NO_IMAGE_PROVIDED;
        public static final int NO_IMAGE_PROVIDED = -1;


        public DataModel(String name, int imageResourceId) {
        this.name = name;
        this.mImageResourceId = imageResourceId;
    }


    public String getNameSinger() {
        return name;
    }

    public boolean hasImage() {
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }

    public int getmImageResourceId() {
        return mImageResourceId;
    }


}
