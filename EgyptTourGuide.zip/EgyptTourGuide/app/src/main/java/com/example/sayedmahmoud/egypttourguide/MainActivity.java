package com.example.sayedmahmoud.egypttourguide;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.design.widget.TabLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle(R.string.main_title);

         ViewPager viewPage = findViewById(R.id.pages);

        TabsAdaptor adapter = new TabsAdaptor(this, getSupportFragmentManager());
          viewPage.setAdapter(adapter);
 TabLayout tabLayout = findViewById(R.id.tabitems);
      tabLayout.setupWithViewPager(viewPage);
    }
}
