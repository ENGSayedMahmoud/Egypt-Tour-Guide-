package com.example.sayedmahmoud.egypttourguide;

/**
 * Created by sayed.mahmoud on 6/12/2019.
 */



import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class PageFourFregmane  extends Fragment{


    public PageFourFregmane() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        final List<DataModel> listitemdata = new ArrayList<>();
        listitemdata.add(new DataModel(getString(R.string.c1),R.drawable.c1));
        listitemdata.add(new DataModel(getString(R.string.c2),R.drawable.c2));
        listitemdata.add(new DataModel(getString(R.string.c3),R.drawable.c3));
        listitemdata.add(new DataModel(getString(R.string.c4),R.drawable.c4));
        listitemdata.add(new DataModel(getString(R.string.c5),R.drawable.c5));


        View rootView = inflater.inflate(R.layout.places_listtaps, container, false);
          DataModelAdaptor dataview = new DataModelAdaptor(getActivity(), listitemdata);

        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(dataview);

        return rootView;
    }




}
