package com.example.sayedmahmoud.egypttourguide;

/**
 * Created by sayed.mahmoud on 6/11/2019.
 */

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class PageOneFragment extends Fragment{


    public PageOneFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        final List<DataModel> listitemdata = new ArrayList<>();
        listitemdata.add(new DataModel(getString(R.string.m1),R.drawable.m1));
        listitemdata.add(new DataModel(getString(R.string.m2),R.drawable.m2));
        listitemdata.add(new DataModel(getString(R.string.m3),R.drawable.m3));
        listitemdata.add(new DataModel(getString(R.string.m4),R.drawable.m4));
        listitemdata.add(new DataModel(getString(R.string.m5),R.drawable.m5));

        View rootView = inflater.inflate(R.layout.places_listtaps, container, false);
        DataModelAdaptor dataview = new DataModelAdaptor(getActivity(), listitemdata);
          ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(dataview);

        return rootView;
    }




}
