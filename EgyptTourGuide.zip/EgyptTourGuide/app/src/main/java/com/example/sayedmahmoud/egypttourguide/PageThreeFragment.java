package com.example.sayedmahmoud.egypttourguide;

/**
 * Created by sayed.mahmoud on 6/12/2019.
 */


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class PageThreeFragment extends Fragment{


    public PageThreeFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        final List<DataModel> listitemdata = new ArrayList<>();
        listitemdata.add(new DataModel(getString(R.string.t1),R.drawable.t1));
        listitemdata.add(new DataModel(getString(R.string.t2),R.drawable.t2));
        listitemdata.add(new DataModel(getString(R.string.t3),R.drawable.t3));
        listitemdata.add(new DataModel(getString(R.string.t4),R.drawable.t4));
        listitemdata.add(new DataModel(getString(R.string.t5),R.drawable.t5));


        View rootView = inflater.inflate(R.layout.places_listtaps, container, false);
        DataModelAdaptor dataview = new DataModelAdaptor(getActivity(), listitemdata);
          ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(dataview);

         return rootView;
    }




}
