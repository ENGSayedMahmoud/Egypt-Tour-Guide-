package com.example.sayedmahmoud.egypttourguide;

/**
 * Created by sayed.mahmoud on 6/11/2019.
 */

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class PageTwoFragment extends Fragment{


    public PageTwoFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        final List<DataModel> listitemdata = new ArrayList<>();
        listitemdata.add(new DataModel(getString(R.string.b1),R.drawable.b1));
        listitemdata.add(new DataModel(getString(R.string.b2),R.drawable.b2));
        listitemdata.add(new DataModel(getString(R.string.b3),R.drawable.b3));
        listitemdata.add(new DataModel(getString(R.string.b4),R.drawable.b4));
        listitemdata.add(new DataModel(getString(R.string.b5),R.drawable.b5));


 View rootView = inflater.inflate(R.layout.places_listtaps, container, false);

        DataModelAdaptor dataview = new DataModelAdaptor(getActivity(), listitemdata);

        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(dataview);

        return rootView;
    }




}
